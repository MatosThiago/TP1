var searchData=
[
  ['nome_5f',['nome_',['../class_leitor.html#a95f125265a504a2b7bad02496cfab0ef',1,'Leitor::nome_()'],['../class_vocabulario_controlado.html#af6bb3f4f8c8bef1de104a370965a4e64',1,'VocabularioControlado::nome_()']]]
];
