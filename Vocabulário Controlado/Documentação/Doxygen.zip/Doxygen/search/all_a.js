var searchData=
[
  ['operator_3d_3d',['operator==',['../class_leitor.html#ad082197dd1b10bc3f47810b96efa1740',1,'Leitor']]]
];
