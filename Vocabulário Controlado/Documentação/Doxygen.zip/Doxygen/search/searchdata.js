var indexSectionsWithContent =
{
  0: "acdefgiklnoprstv~",
  1: "acdefilnrstv",
  2: "acdeist",
  3: "acdegilnorstv~",
  4: "cdeklnst",
  5: "cp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Macros"
};

