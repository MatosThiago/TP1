var searchData=
[
  ['pause',['PAUSE',['../includes_8h.html#a5666ac5930c9f903698073ab1fa694f7',1,'includes.h']]]
];
