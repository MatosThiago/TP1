var searchData=
[
  ['telefone',['Telefone',['../class_telefone.html#abf977c888ed9b52ad31daf0f9c2c2375',1,'Telefone::Telefone(const string &amp;_telefone)'],['../class_telefone.html#a52e911b5f3415763ad05afc4381ea858',1,'Telefone::Telefone()=default']]],
  ['termo',['Termo',['../class_termo.html#a35df79c8bcc5f305d50aeca455a4287f',1,'Termo::Termo(const Nome &amp;_nome, const ClasseDoTermo &amp;_preferencia, const Data &amp;_data)'],['../class_termo.html#a07aaa15240661e5848ac9e51f7b21846',1,'Termo::Termo()=default']]],
  ['textodefinicao',['TextoDefinicao',['../class_texto_definicao.html#aca2b2bd4a8d144be0e2cf7ca22e8a5d5',1,'TextoDefinicao::TextoDefinicao(const string &amp;_definicao)'],['../class_texto_definicao.html#ababa2523cd4e22b126ef6f9e9e79ebb4',1,'TextoDefinicao::TextoDefinicao()=default']]],
  ['tubasedominios',['TUBaseDominios',['../class_t_u_base_dominios.html#a1512b5b94e76c688e0376ed31b147285',1,'TUBaseDominios']]]
];
