var searchData=
[
  ['kfalha_5f',['kfalha_',['../class_resultado.html#a966ba38d4574bae1dc43dbb60695b5f7',1,'Resultado']]],
  ['ksucesso_5f',['ksucesso_',['../class_resultado.html#a83795c5584e54d7839adf55a0e274238',1,'Resultado']]]
];
