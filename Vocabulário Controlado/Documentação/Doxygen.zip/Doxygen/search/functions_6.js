var searchData=
[
  ['leitor',['Leitor',['../class_leitor.html#a5848a1fba56333ad6e977b791bd607ae',1,'Leitor::Leitor(const Nome &amp;_nome, const Sobrenome &amp;_sobrenome, const Senha &amp;_senha, const Email &amp;_email)'],['../class_leitor.html#a4dd6a7d0373d1f0ae2d69037d6de404c',1,'Leitor::Leitor()=default']]]
];
