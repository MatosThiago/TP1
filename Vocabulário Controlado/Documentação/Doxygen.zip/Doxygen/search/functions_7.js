var searchData=
[
  ['nome',['Nome',['../class_nome.html#a48211e3885d9374fb2879dc80971ebe9',1,'Nome::Nome(const string &amp;_nome)'],['../class_nome.html#a7a232445ace414f29bab4a51378952c8',1,'Nome::Nome()=default']]]
];
