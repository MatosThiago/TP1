var searchData=
[
  ['leitor',['Leitor',['../class_leitor.html',1,'Leitor'],['../class_leitor.html#a5848a1fba56333ad6e977b791bd607ae',1,'Leitor::Leitor(const Nome &amp;_nome, const Sobrenome &amp;_sobrenome, const Senha &amp;_senha, const Email &amp;_email)'],['../class_leitor.html#a4dd6a7d0373d1f0ae2d69037d6de404c',1,'Leitor::Leitor()=default']]],
  ['lista_5fresultado_5f',['lista_resultado_',['../class_comando_sql.html#adf6ed21378cbe92ca6164e09abfa3de7',1,'ComandoSql']]]
];
