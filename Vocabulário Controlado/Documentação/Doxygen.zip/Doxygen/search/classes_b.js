var searchData=
[
  ['vocabulariocontrolado',['VocabularioControlado',['../class_vocabulario_controlado.html',1,'']]]
];
