var searchData=
[
  ['lista_5fresultado_5f',['lista_resultado_',['../class_comando_sql.html#adf6ed21378cbe92ca6164e09abfa3de7',1,'ComandoSql']]]
];
