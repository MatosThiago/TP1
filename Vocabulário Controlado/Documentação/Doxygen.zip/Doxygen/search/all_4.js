var searchData=
[
  ['fts5_5fapi',['fts5_api',['../structfts5__api.html',1,'']]],
  ['fts5_5ftokenizer',['fts5_tokenizer',['../structfts5__tokenizer.html',1,'']]],
  ['fts5extensionapi',['Fts5ExtensionApi',['../struct_fts5_extension_api.html',1,'']]],
  ['fts5phraseiter',['Fts5PhraseIter',['../struct_fts5_phrase_iter.html',1,'']]]
];
