var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#a76e25c287629f369849bbaaf945ffc08',1,'Idioma::Idioma(const string &amp;_idioma)'],['../class_idioma.html#a9794a9623fb00faf5e2d5b3fc249263e',1,'Idioma::Idioma()=default']]],
  ['inicializar',['Inicializar',['../class_ctrl_apresentacao_controle.html#a5694de95278bb905354ccc6250ccd393',1,'CtrlApresentacaoControle::Inicializar()'],['../class_interface_apresentacao_controle.html#a5f5231dde4c74def5af45b82683058ea',1,'InterfaceApresentacaoControle::Inicializar()']]]
];
