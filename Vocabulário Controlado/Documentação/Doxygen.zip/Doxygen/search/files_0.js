var searchData=
[
  ['auxiliares_2eh',['auxiliares.h',['../auxiliares_8h.html',1,'']]]
];
